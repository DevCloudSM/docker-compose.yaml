from flask import Flask, render_template, request, jsonify, Response
import json
import requests
import python_sql as ps

app = Flask(__name__)

nom_db = 'licenses'


@app.route('/', endpoint='page_accueil')
def index():
    """
    Render the index HTML page.

    :return: The index HTML page.
    :rtype: str
    """
    return render_template("index_licenses.j2")


# Endpoints des objets Site


@app.route('/site', methods=['GET', 'POST'])
def site():
    if request.method == 'POST':                                # si la méthode est POST
        site_fields = request.get_json()
        test = ps.post(f'{nom_db}', 'site', {key:value for key,value in site_fields.items()})
        return f"Succès de l'opération : {test}"
    elif request.method == 'GET':                               # si la méthode est GET
        result = ps.get(f'{nom_db}', ['site'])
        return jsonify(result)


@app.route('/site/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findSiteById(id: int) -> Response | str:
    if request.method == 'GET':                                 # si la méthode est GET
        result = ps.get(f'{nom_db}', ["site"], "id", "=", id)
        return jsonify(result)
    elif request.method == 'PATCH':                             # si la méthode est PATCH
        #result = ps.patch(f'{nom_db}', ["site"], id, request.get_json())
        #return jsonify(result)
        site_fields = request.get_json()
        print({key:value for key,value in site_fields.items()})
        result = ps.patch(f'{nom_db}', 'site', id, {key:value for key,value in site_fields.items()})
        return jsonify(result)
    elif request.method == 'DELETE':                            # si la méthode est DELETE
        result = ps.delete(f'{nom_db}', 'site', id)
        return jsonify(result)


@app.route('/site/findByName', methods=['GET'])
def findSiteByName():
        result = ps.get(f'{nom_db}', ["site"], "name", "ILIKE", "%"+request.args.get('name')+"%")
        return jsonify(result)


# Endpoints des objets Provider


@app.route('/provider', methods=['GET', 'POST'])
def provider():
    if request.method == 'POST':                                # si la méthode est POST
        provider_fields = request.get_json()
        test = ps.post(f'{nom_db}', 'provider', {key:value for key,value in provider_fields.items()})
        return f"Succès de l'opération : {test}"
    elif request.method == 'GET':                               # si la méthode est GET
        result = ps.get(f'{nom_db}', ['provider'])
        return jsonify(result)


@app.route('/provider/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findProviderById(id):
    if request.method == 'GET':                                 # si la méthode est GET
        result = ps.get(f'{nom_db}', ["provider"], "id", "=", id)
        return jsonify(result)
    elif request.method == 'PATCH':                             # si la méthode est PATCH
        provider_fields = request.get_json()
        print({key:value for key,value in provider_fields.items()})
        result = ps.patch(f'{nom_db}', 'provider', id, {key:value for key,value in provider_fields.items()})
        return jsonify(result)
    elif request.method == 'DELETE':                            # si la méthode est DELETE
        result = ps.delete(f'{nom_db}', 'provider', id)
        return jsonify(result)


@app.route('/provider/findByName', methods=['GET'])
def findProviderByName():
    result = ps.get(f'{nom_db}', ["provider"], "name", "ILIKE", "%"+request.args.get('name')+"%")
    return jsonify(result)


# Endpoints des objets Product


@app.route('/product', methods=['GET', 'POST'])
def product():
    if request.method == 'POST':                                 # si la méthode est POST
        product_fields = request.get_json()
        test = ps.post(f'{nom_db}', 'product', {key:value for key,value in product_fields.items()})
        return f"Succès de l'opération : {test}"
    elif request.method == 'GET':                                # si la méthode est GET
        result = ps.get(f'{nom_db}', ['product'])
        return jsonify(result)


@app.route('/product/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findProductById(id):
    if request.method == 'GET':                                 # si la méthode est GET
        result = ps.get(f'{nom_db}', ['product'], 'id', '=', id)
        return jsonify(result)
    elif request.method == 'PATCH':                             # si la méthode est PATCH
        product_fields = request.get_json()
        result = ps.patch(f'{nom_db}', 'product', id, {key:value for key,value in product_fields.items()})
        return jsonify(result)
    elif request.method == 'DELETE':                            # si la méthode est DELETE
        result = ps.delete(f'{nom_db}', 'product', id)
        return jsonify(result)


@app.route('/product/findByName', methods=['GET'])
def findProductByName():
    result = ps.get(f'{nom_db}', ['product'], 'name', 'ILIKE', '%'+request.args.get('name')+'%')
    return jsonify(result)


# Endpoints des objets Licenses


@app.route('/license', methods=['GET', 'POST'])
def license():
    if request.method == 'POST':                                # Si la méthode est POST
        license_fields = request.get_json()
        test = ps.post(f'{nom_db}', 'license', {key:value for key,value in license_fields.items()})
        return f"Succès de l'opération : {test}"
    elif request.method == 'GET':                               # Si la méthode est GET
        result = ps.get(f'{nom_db}', ["license"])
        return jsonify(result)


@app.route('/license/<id>', methods=['GET', 'PATCH', 'DELETE'])
def findLicenseById(id):
    if request.method == 'GET':                                 # si la méthode est GET
        result = ps.get(f'{nom_db}', ["license"], "id", "=", id)
        return jsonify(result)
    elif request.method == 'PATCH':                             # si la méthode est PATCH
        license_fields = request.get_json()
        print({key:value for key,value in license_fields.items()})
        result = ps.patch(f'{nom_db}', 'license', id, {key:value for key,value in license_fields.items()})
        return jsonify(result)
    elif request.method == 'DELETE':                            # si la méthode est DELETE
        result = ps.delete(f'{nom_db}', 'license', id)
        return jsonify(result)


@app.route('/license/findByKey', methods=['GET'])
def findLicenseByKey():
    result = ps.get(f'{nom_db}', ["license"], "key", "ILIKE", "%"+request.args.get('key')+"%")
    return jsonify(result)


@app.route('/license/findByIsUsed', methods=['GET'])
def findLicenseByIsUsed():
    result = ps.get(f'{nom_db}', ["license"], "is_used", "=", request.args.get('boolean').lower())
    return jsonify(result)


@app.route('/license/findByUserId', methods=['GET'])
def findLicenseByUserId():
    result = ps.get(f'{nom_db}', ["license"], "user_id", "=", request.args.get('user_id'))
    return jsonify(result)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5009)