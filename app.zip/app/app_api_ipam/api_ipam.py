from flask import Flask, request, jsonify, redirect, render_template
import python_sql as ps

api_ipam = Flask(__name__)

@api_ipam.route("/")
def index():
    return redirect('/ipam/')

#Group
# Code fait !
@api_ipam.route("/group/", methods = ['POST'])
def slash_group():
    try:
        if request.method == 'POST':
            succes = ps.put('ipam','group', request.get_json())
            return ("",200) if succes else ("", 400)
        """
        Code si jamais il y avait un GET /group/
        groupes = ps.get('ipam',['group'])
        return jsonify(groupes)
        """
    except:
        return "", 400

# Code fait !
@api_ipam.route("/group/<groupId>", methods = ['GET','DELETE','PATCH'])
def slash_group_groupId(groupId):
    try:
        groupId = int(groupId)
    except:
        return "", 400
    groupes = ps.get('ipam',['group'])
    if groupId not in [groupe[0] for groupe in groupes]:
        return "", 404
    if request.method == 'GET':
        groupes = ps.get('ipam',['group'], 'id', groupId)
        return jsonify(groupes), 200
    if request.method == 'DELETE':
        succes = ps.delete('ipam','group', groupId)
    if request.method == 'PATCH':
        succes = ps.delete('ipam','group', groupId) and ps.put('ipam','group', request.get_json())
    return ("", 200) if succes else ("", 400)

# Code fait !
@api_ipam.route("/group/findByName", methods = ['GET'])
def slash_group_findByName():
    name = request.args.get("name")
    groupes = ps.get('ipam',['group'], 'name', name)
    return (jsonify(groupes), 200) if groupes else ("", 400)

# Code fait !
@api_ipam.route("/group/findByParent", methods = ['GET'])
def slash_group_findByParent():
    parent_id = request.args.get("parent")
    groupes = ps.get('ipam',['group'], 'parent_id', parent_id)
    return (jsonify(groupes), 200) if groupes else ("", 400)

# Code fait !
@api_ipam.route("/group/findByChild", methods = ['GET'])
def slash_group_findByChild():
    child_id = request.args.get("child")
    groupes = ps.get('ipam',['group'])
    groupes = [groupe for groupe in groupes if child_id in str(groupe[3])]
    return (jsonify(groupes), 200) if groupes else ("", 400)



#Address
# Code fait !
@api_ipam.route("/address/", methods = ['POST'])
def slash_address():
    try:
        succes = ps.put('ipam','address',request.get_json())
        return ("", 200) if succes else ("", 400)
    except:
        return "", 400

# Code fait !
@api_ipam.route("/address/<addressId>", methods = ['GET','DELETE','PATCH'])
def slash_address_addressId(addressId):
    try:
        addressId = int(addressId)
    except:
        return "", 400
    adresses = ps.get('ipam', ['address'])
    if addressId not in [adresse[0] for adresse in adresses]:
        return "", 404
    if request.method == 'GET':
        adresses = ps.get('ipam', ['address'], 'id', addressId)
        return jsonify(adresses), 200
    if request.method == 'DELETE':
        succes = ps.delete('ipam', 'address', addressId)
    if request.method == 'PATCH':
        succes = ps.delete('ipam', 'address', addressId) and ps.put('ipam', 'address', request.get_json())
    return ("", 200) if succes else ("", 400)

# Code fait !
@api_ipam.route("/address/findByAddress", methods = ['GET'])
def slash_address_findByAddress():
    address = request.args.get("address")
    adresses = ps.get('ipam', ['address'], 'address', address)
    ps.log(adresses)
    return (jsonify(adresses), 200) if adresses else ("", 400)



#Subnet
# Code à tester
@api_ipam.route("/subnet/", methods = ['POST'])
def slash_subnet():
    try:
        succes = ps.put('ipam', 'subnet', request.get_json())
        return ("", 200) if succes else ("", 400)
    except:
        return "", 400

# Code à tester
@api_ipam.route("/subnet/<subnetId>", methods = ['GET','DELETE', 'PATCH'])
def slash_subnet_subnetId(subnetId):
    try:
        subnetId = int(subnetId)
    except:
        return "", 400
    subnets = ps.get('ipam', ['subnet'])
    if subnetId not in [sub[0] for sub in subnets]:
        return "", 404
    if request.method == 'GET':
        subnets = ps.get('ipam', ['subnet'], id, subnetId)
        return jsonify(subnets), 200
    if request.method == 'DELETE':
        succes = ps.delete('ipam', 'subnet', subnetId)
    if request.method == 'PATCH':
        succes = ps.delete('ipam', 'subnet', subnetId) and ps.put('ipam', 'subnet', request.get_json())
    return ("", 20) if succes else ("", 400)

# Code à faire, dont il faut rédiger un test, dont le test ne fonctionne pas
@api_ipam.route("/subnet/findByName", methods = ['GET'])
def slash_subnet_findByName():
    return "<h1>GET subnet findByName</h1>"

# Code à faire, dont il faut rédiger un test, dont le test ne fonctionne pas
@api_ipam.route("/subnet/findByParent", methods = ['GET'])
def slash_subnet_findByParent():
    return "<h1>GET subnet findByParent</h1>"

# Code à faire, dont il faut rédiger un test, dont le test ne fonctionne pas
@api_ipam.route("/subnet/findByChild", methods = ['GET'])
def slash_subnet_findByChild():
    return "<h1>GET subnet findByChild</h1>"



@api_ipam.route("/ipam/", methods=['GET'])
def menu():
    group_id = request.args.get("group") if request.args.get("group") else 0
    cles_groupe = ['id','name','parent_id', 'content_id','r_r','w_r']
    cles_subnet = ['id','first_address','last_address', 'desc','mask','r_r','w_r','g_id']
    groupes = ps.get('ipam',['group'])
    groupes = [{key:value for key,value in zip(cles_groupe, groupe)} for groupe in groupes]
    contenu_groupe = ps.get('ipam',['group'], 'parent_id',group_id)
    contenu_groupe = [{key:value for key,value in zip(cles_groupe, cont)} for cont in contenu_groupe]
    contenu_subnet = ps.get('ipam',['subnet'], 'group_id',group_id)
    contenu_subnet = [{key:value for key,value in zip(cles_subnet, cont)} for cont in contenu_subnet]
    contenu = contenu_groupe + contenu_subnet
    return render_template('ipam.html', tree=groupes, groupes=contenu_groupe, subnets=contenu_subnet)

if __name__ == "__main__":
    api_ipam.run(debug=True)