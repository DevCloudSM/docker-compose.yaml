import psycopg2
from psycopg2 import OperationalError

def create_database(database_name):
    try:
        # Paramètres de connexion
        db_params = {
            'user': 'postgres',
            'password': 'bonjour',
            'host': 'localhost',
            'port': 5432
        }

        # Connexion au serveur PostgreSQL pour créer la base de données
        conn = psycopg2.connect(**db_params)

        # Création d'un nouveau curseur
        conn.autocommit = True
        cursor = conn.cursor()

        # Création de la base de données
        cursor.execute(f"CREATE DATABASE {database_name};")
        print(f"Base de données '{database_name}' créée avec succès !")

    except OperationalError as e:
        print(f"Erreur: {e}")


def create_table(database_name, table_name):
    try:
        # Paramètres de connexion pour se connecter à la base de données
        db_params = {
            'database': database_name,
            'user': 'postgres',
            'password': 'bonjour',
            'host': 'localhost',
            'port': 5432
        }

        # Connexion à la base de données
        conn = psycopg2.connect(**db_params)

        # Création d'un nouveau curseur pour la base de données
        conn.autocommit = True
        cursor = conn.cursor()

        # Vérifier si la table existe déjà
        cursor.execute(f"SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = '{table_name}');")
        table_exists = cursor.fetchone()[0]

        if not table_exists:
            # Création de la table en fonction de la BDD
            if table_name == 'site':
                cursor.execute(f"CREATE TABLE {table_name} (id SERIAL PRIMARY KEY, name VARCHAR(50));")
            elif table_name == 'address':
                cursor.execute(f"CREATE TABLE {table_name} (id SERIAL PRIMARY KEY, address VARCHAR(50), mask INT, online BOOLEAN, attributed BOOLEAN);")
            elif table_name == 'subnet':
                cursor.execute(f"CREATE TABLE {table_name} (id SERIAL PRIMARY KEY, first_address VARCHAR(50), last_address VARCHAR(50), description TEXT, mask INT, reading_roles TEXT[], writing_roles TEXT[], vlan_id INT);")
            print(f"Table '{table_name}' créée avec succès dans la base de données '{database_name}'!")
        else:
            print(f"La table '{table_name}' existe déjà dans la base de données '{database_name}'.")
    except OperationalError as e:
        print(f"Erreur: {e}")

def insert_into(database_name, table_name, values):
    try:
        # Paramètres de connexion pour se connecter à la base de données
        db_params = {
            'database': database_name,
            'user': 'postgres',
            'password': 'bonjour',
            'host': 'localhost',
            'port': 5432
        }

        # Connexion à la base de données
        with psycopg2.connect(**db_params) as conn:
            # Création d'un nouveau curseur pour la base de données
            conn.autocommit = True
            cursor = conn.cursor()

            # Insertion des valeurs dans la table
            for value in values:
                cursor.execute(f"INSERT INTO {table_name} (name) VALUES ('tuple(values');")
            print(f"Données insérées avec succès dans la table '{table_name}' de la base de données '{database_name}'")

    except OperationalError as e:
        print(f"Erreur: {e}")

def insert_address(database_name, table_name, address, mask, online, attributed):
    try:
        # Paramètres de connexion
        db_params = {
            'database': database_name,
            'user': 'postgres',
            'password': 'bonjour',
            'host': 'localhost',
            'port': 5432
        }

        # Connexion à la base de données
        conn = psycopg2.connect(**db_params)
        cursor = conn.cursor()

        # Création de la commande SQL d'insertion
        sql_command = f"""
            INSERT INTO {table_name} (address, mask, online, attributed)
            VALUES ('{address}', {mask}, {online}, {attributed});
        """

        # Exécution de la commande SQL
        cursor.execute(sql_command)
        conn.commit()
        print(f"Données insérées avec succès dans la table '{table_name}' de la base de données '{database_name}'")

    except OperationalError as e:
        print(f"Erreur: {e}")

    finally:
        # Fermeture de la connexion
        if conn:
            conn.close()

def insert_subnet(database_name, table_name, subnet_data):
    try:
        # Paramètres de connexion
        db_params = {
            'database': database_name,
            'user': 'postgres',
            'password': 'bonjour',
            'host': 'localhost',
            'port': 5432
        }

        # Connexion à la base de données
        conn = psycopg2.connect(**db_params)
        cursor = conn.cursor()

        # Création de la commande SQL d'insertion
        sql_command = f"""
        INSERT INTO {table_name} (id, first_address, last_address, description, mask, reading_roles, writing_roles, vlan_id)
        VALUES {subnet_data};
        """

        # Exécution de la commande SQL
        cursor.execute(sql_command)

        conn.commit()
        print("Données insérées avec succès dans la table Subnet!")

    except OperationalError as e:
        print(f"Erreur: {e}")

    finally:
        # Fermeture de la connexion
        if conn:
            conn.close()

if __name__ == "__main__":

    # Création de la base de données IPAM
    #create_database("ipam")

    # Créer une table site dans la base de données
    #create_table("ipam", "site")

    #Insérer des données dans la table site
    values_to_insert = ['Saint-Malo', 'Vannes', 'Nantes', 'Rennes']
    #insert_into("ipam", "site", values_to_insert)

    # Créer une table address dans la base de données
    #create_table("ipam", "address")

    # Insérer des adresses IP dans la table Address
    #insert_address("ipam", "address", '192.168.0.1', 24, True, False)

    # Créer une table subnet dans la base de données
    #create_table("ipam", "subnet")

    #Insérer des numéros de réseau dans la table Subnet
    values_to_insert = """
    (1, '192.168.0.0', '192.168.0.255', 'Range for Office LAN', 24, '{"admin", "manager"}', '{"admin", "manager"}', 100),
    (2, '10.0.0.0', '10.0.0.255', 'Range for Data Center', 24, '{"admin", "network_admin"}', '{"admin", "network_admin"}', 200)
    """
    insert_subnet("ipam", "subnet", values_to_insert)